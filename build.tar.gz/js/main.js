document.addEventListener('DOMContentLoaded', function() {
    // Initialize dropzone
    new Dropzone(".dropzone", {
        url: "/file/post",
        dictDefaultMessage: '<i class="fas fa-cloud-upload-alt"></i><br>Drop images here or click to upload',
        createImageThumbnails: true,
        maxFilesize: 10,
        acceptedFiles: 'image/*'
    });

    // Category input handling
    const addCategoryBtn = document.querySelector('.btn-primary');
    const categoryInputs = document.querySelector('.category-inputs');
    let categoryCount = 2;

    if (addCategoryBtn) {
        addCategoryBtn.addEventListener('click', function() {
            categoryCount++;
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'category-input';
            input.placeholder = `Category ${categoryCount}`;
            categoryInputs.appendChild(input);
        });
    }
});
